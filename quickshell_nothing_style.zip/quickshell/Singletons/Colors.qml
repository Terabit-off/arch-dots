import QtQuick
pragma Singleton

QtObject {
    // Nothing-inspired monochrome system
    readonly property string uiFont: "JetBrainsMono Nerd Font"
    readonly property string iconFont: "JetBrainsMono Nerd Font"

    // Brand palette
    readonly property color nothingRed: "#FF001A"
    readonly property color black: "#050505"
    readonly property color blackSoft: "#0B0B0B"
    readonly property color white: "#F5F5F5"
    readonly property color grey90: "#D9D9D9"
    readonly property color grey70: "#A6A6A6"
    readonly property color grey50: "#747474"
    readonly property color grey30: "#444444"
    readonly property color grey15: "#242424"

    // Base
    readonly property color barBackground: "#E6050505"
    readonly property color foreground: white
    readonly property color foregroundDim: grey70
    readonly property color foregroundMuted: grey50
    readonly property color barBorderColor: "#FF242424"
    readonly property color barModuleColor: "#F00B0B0B"
    readonly property color criticalColor: nothingRed
    readonly property color warningColor: nothingRed
    readonly property color successColor: white
    readonly property color weekendColor: nothingRed

    // Common surfaces / states
    readonly property color surface: "#F00B0B0B"
    readonly property color surfaceElevated: "#F0141414"
    readonly property color surfaceInput: "#151515"
    readonly property color surfaceSelected: "#252525"
    readonly property color surfaceHover: "#18FFFFFF"
    readonly property color surfaceActive: "#28FFFFFF"
    readonly property color border: "#FF3A3A3A"
    readonly property color borderSubtle: "#2AFFFFFF"
    readonly property color separator: "#303030"

    // Buttons
    readonly property color buttonBackgroundColor: "transparent"
    readonly property color buttonBackgroundColorHover: surfaceHover
    readonly property color activeButtonBackgroundColor: "#24FFFFFF"

    // Workspaces
    readonly property color wsUrgentForeground: white
    readonly property color wsFocusForeground: black
    readonly property color wsNotFocusForeground: grey50
    readonly property color wsFocusBackground: nothingRed
    readonly property color wsUrgentBackground: "#22FF001A"
    readonly property color wsNotFocusBackground: "transparent"
    readonly property color separatorColor: "#666666"

    // Menus
    readonly property color menuBackground: "#F8080808"
    readonly property color menuBackgroundElevated: "#F0141414"
    readonly property color menuBorderColor: border
    readonly property real menuBorderRadius: 4
    readonly property real menuPadding: 16
    readonly property real menuSectionSpacing: 12
    readonly property real controlRadius: 2
    readonly property real cardRadius: 3
    readonly property color menuHeaderBackground: "#12000000"
    readonly property color controlHover: "#18FFFFFF"
    readonly property color controlActive: "#28FFFFFF"
    readonly property color controlBorder: "#333333"
    readonly property color controlBorderHover: "#666666"
    readonly property color textSecondary: grey70
    readonly property color textTertiary: grey50
    readonly property color successSubtle: "#18FFFFFF"
    readonly property color warningSubtle: "#22FF001A"
    readonly property color dangerSubtle: "#22FF001A"

    // Sliders
    readonly property color sliderBackgroundColor: "#363636"
    readonly property color sliderBackgroundFillColor: white
    readonly property color sliderHandlerColor: nothingRed
    readonly property color sliderHandlerBorderColor: black
    readonly property real sliderHandlerBorderRadius: 0

    // Notifications
    readonly property color notifiCardBackground: "#F00E0E0E"
    readonly property color notifiCardCriticalBackground: "#F01A080A"
    readonly property color notifiCardBorderBackground: "#FF444444"
    readonly property color notifiCardHoverBorderBackground: white

    // Overview / Cards
    readonly property color overviewBackground: "#F8080808"
    readonly property color overviewCardBackground: "#161616"
    readonly property color overviewCardHoverBackground: "#242424"
    readonly property color overviewCardBorder: "#333333"
    readonly property color overviewCardHoverBorder: "#FF707070"
    readonly property real overviewBorderRadius: 3

    // Dock
    readonly property color dockAccent: white
    readonly property color dockAccentDim: "#68FFFFFF"
    readonly property color dockPopupBackground: surfaceElevated
    readonly property color dockWindowBackground: "#12000000"
    readonly property color dockWindowHoverBackground: "#20FFFFFF"
    readonly property color dockWindowCurrentBackground: "#18FF001A"
    readonly property color dockWindowBorder: "#22303030"
    readonly property color dockWindowHoverBorder: "#555555"
    readonly property color dockWindowCurrentBorder: nothingRed
    readonly property color dockSeparator: "#303030"
}
